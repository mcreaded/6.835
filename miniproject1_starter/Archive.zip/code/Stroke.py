class Stroke:

    def __init__(self, x, y, time):
        self.x = x
        self.y = y
        self.time = time